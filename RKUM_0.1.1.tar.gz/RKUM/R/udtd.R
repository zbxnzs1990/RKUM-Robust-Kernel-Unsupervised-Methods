udtd <-
function(x) {ifelse(x==0,0,1/x)}
