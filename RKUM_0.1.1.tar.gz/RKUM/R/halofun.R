halofun <-
function(x)
   {
   y <- halfun(x)
   obj<-mean(y)
   return(obj)
  }
