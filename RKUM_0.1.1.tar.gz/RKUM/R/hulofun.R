hulofun <-
function(x)
  {
   y<- hulfun(x)
   obj<-mean(y)
  return(obj)
  }
