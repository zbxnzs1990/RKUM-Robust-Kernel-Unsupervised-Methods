rlogit <-
function(x)  1/(1+exp(-x))
